from django.contrib.auth.models import Group
from django.core.management.base import BaseCommand
from api_shop.models import User, Product, Category, Tag

class Command(BaseCommand):
    help = 'Initialize project with test data'

    def handle(self, *args, **kwargs):
        # Создание групп
        superuser_group, _ = Group.objects.get_or_create(name='Superuser')
        admin_group, _ = Group.objects.get_or_create(name='Admin')
        seller_group, _ = Group.objects.get_or_create(name='Seller')
        customer_group, _ = Group.objects.get_or_create(name='Customer')

        # Создание суперпользователя
        superuser = User.objects.create_superuser(
            username='superuser',
            email='superuser@example.com',
            password='superpass'
        )
        superuser.groups.add(superuser_group)
        superuser.save()

        # Создание администраторов
        for i in range(1, 3):
            admin = User.objects.create_user(
                username=f'admin{i}',
                email=f'admin{i}@example.com',
                password=f'adminpass{i}',
                is_admin=True
            )
            admin.groups.add(admin_group)
            admin.save()

        # Создание продавцов
        for i in range(1, 4):
            seller = User.objects.create_user(
                username=f'seller{i}',
                email=f'seller{i}@example.com',
                password=f'sellerpass{i}',
                is_seller=True
            )
            seller.groups.add(seller_group)
            seller.save()

        # Создание покупателей
        for i in range(1, 5):
            customer = User.objects.create_user(
                username=f'customer{i}',
                email=f'customer{i}@example.com',
                password=f'customerpass{i}',
                is_customer=True
            )
            customer.groups.add(customer_group)
            customer.save()

        # Создание тестовых данных
        category1 = Category.objects.create(name='Электроника', description='Электронные устройства')
        category2 = Category.objects.create(name='Одежда', description='Одежда и аксессуары')

        tag1 = Tag.objects.create(name='Новинка')
        tag2 = Tag.objects.create(name='Распродажа')
        tag3 = Tag.objects.create(name='Премиум')

        product1 = Product.objects.create(
            name='Смартфон',
            description='Новый смартфон',
            price=50000,
            category=category1
        )
        product1.tags.add(tag1, tag3)
        product1.save()

        product2 = Product.objects.create(
            name='Футболка',
            description='Хлопковая футболка',
            price=1500,
            category=category2
        )
        product2.tags.add(tag2)
        product2.save()

        self.stdout.write(self.style.SUCCESS('Successfully initialized the database'))