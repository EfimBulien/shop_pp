from django.test import TestCase
from django.urls import reverse
from rest_framework.test import APIClient
from django.contrib.auth.models import User
from .models import Product, Category, Tag

class APITestCase(TestCase):
    def setUp(self):
        # Создание тестовых пользователей
        self.superuser = User.objects.create_superuser(
            username='superuser', password='superpass', email='super@example.com'
        )
        self.admin = User.objects.create_user(
            username='admin', password='adminpass', email='admin@example.com', is_admin=True
        )
        self.seller = User.objects.create_user(
            username='seller', password='sellerpass', email='seller@example.com', is_seller=True
        )
        self.customer = User.objects.create_user(
            username='customer', password='customerpass', email='customer@example.com', is_customer=True
        )
        
        # Создание тестовых данных
        self.category = Category.objects.create(name='Test Category', description='Test')
        self.tag = Tag.objects.create(name='Test Tag')
        self.product = Product.objects.create(
            name='Test Product', description='Test', price=100, category=self.category
        )
        self.product.tags.add(self.tag)
        
        self.client = APIClient()

    def test_product_list_access(self):
        # Проверка доступа к списку продуктов для разных пользователей
        users = [self.superuser, self.admin, self.seller, self.customer]
        for user in users:
            self.client.force_authenticate(user=user)
            response = self.client.get(reverse('product-list'))
            self.assertEqual(response.status_code, 200)

    def test_product_create_access(self):
        # Проверка доступа на создание продукта
        data = {
            'name': 'New Product',
            'description': 'New',
            'price': 200,
            'category': self.category.id,
            'tags': [self.tag.id]
        }
        
        # Суперпользователь, администратор и продавец могут создавать
        allowed_users = [self.superuser, self.admin, self.seller]
        for user in allowed_users:
            self.client.force_authenticate(user=user)
            response = self.client.post(reverse('product-list'), data)
            self.assertEqual(response.status_code, 201)
        
        # Покупатель не может создавать
        self.client.force_authenticate(user=self.customer)
        response = self.client.post(reverse('product-list'), data)
        self.assertEqual(response.status_code, 403)

    def test_product_delete_access(self):
        # Проверка доступа на удаление продукта
        # Только суперпользователь и администратор могут физически удалять
        allowed_users = [self.superuser, self.admin]
        for user in allowed_users:
            product = Product.objects.create(
                name=f'Product for {user.username}',
                description='Test',
                price=100,
                category=self.category
            )
            self.client.force_authenticate(user=user)
            response = self.client.delete(reverse('product-detail', args=[product.id]))
            self.assertEqual(response.status_code, 204)
        
        # Продавец может только логически удалять (is_active=False)
        product = Product.objects.create(
            name='Product for seller',
            description='Test',
            price=100,
            category=self.category
        )
        self.client.force_authenticate(user=self.seller)
        response = self.client.delete(reverse('product-detail', args=[product.id]))
        self.assertEqual(response.status_code, 204)
        product.refresh_from_db()
        self.assertFalse(product.is_active)