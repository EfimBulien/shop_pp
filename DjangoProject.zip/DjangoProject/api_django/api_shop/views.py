from rest_framework import viewsets, permissions
from rest_framework.response import Response
from rest_framework.decorators import action
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from .models import Product, Category, Tag
from .serializers import ProductSerializer, CategorySerializer, TagSerializer
import django_filters.rest_framework

class IsSuperUser(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user.is_superuser

class IsAdminUser(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user.is_admin or request.user.is_superuser

class IsSellerUser(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user.is_seller or request.user.is_admin or request.user.is_superuser

class IsCustomerUser(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user.is_customer or request.user.is_seller or request.user.is_admin or request.user.is_superuser

@method_decorator(login_required, name='dispatch')
class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.filter(is_active=True)
    serializer_class = ProductSerializer
    filter_backends = [django_filters.rest_framework.DjangoFilterBackend]
    filterset_fields = ['category', 'tags', 'price']

    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            permission_classes = [IsCustomerUser]
        elif self.action in ['create', 'update', 'partial_update']:
            permission_classes = [IsSellerUser]
        elif self.action == 'destroy':
            permission_classes = [IsAdminUser]
        else:
            permission_classes = [permissions.IsAuthenticated]
        return [permission() for permission in permission_classes]

    def perform_destroy(self, instance):
        if self.request.user.is_superuser or self.request.user.is_admin:
            instance.delete()  # Физическое удаление
        else:
            instance.is_active = False
            instance.save()  # Логическое удаление

    @action(detail=True, methods=['post'], permission_classes=[IsSellerUser|IsAdminUser])
    def restore(self, request, pk=None):
        product = self.get_object()
        product.restore()
        return Response({'status': 'product restored'})

@method_decorator(login_required, name='dispatch')
class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.filter(is_active=True)
    serializer_class = CategorySerializer

    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            permission_classes = [IsCustomerUser]
        else:
            permission_classes = [IsAdminUser]
        return [permission() for permission in permission_classes]

@method_decorator(login_required, name='dispatch')
class TagViewSet(viewsets.ModelViewSet):
    queryset = Tag.objects.filter(is_active=True)
    serializer_class = TagSerializer

    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            permission_classes = [IsCustomerUser]
        else:
            permission_classes = [IsAdminUser]
        return [permission() for permission in permission_classes]
    