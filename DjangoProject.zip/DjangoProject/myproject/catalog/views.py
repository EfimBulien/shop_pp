from django.shortcuts import render, get_object_or_404, redirect
from django.views.decorators.http import require_POST
from django.views.generic import ListView, DetailView, CreateView
from .models import Product, Category, Tag, Order, OrderItem
from .forms import ProductForm, CategoryForm, OrderForm
from datetime import timezone

#добавим следующие методы
from .utils import (
    get_cart_items, add_to_cart, remove_from_cart,
    update_cart_item, clear_cart, get_cart_total,
    get_cart_items_count
)

@require_POST
def cart_add(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    quantity = int(request.POST.get('quantity', 1))
    add_to_cart(request, product_id, quantity)
    return redirect('cart_detail')

@require_POST
def cart_remove(request, product_id):
    remove_from_cart(request, product_id)
    return redirect('cart_detail')

def cart_detail(request):
    cart_items = get_cart_items(request)
    cart_total = get_cart_total(request)
    cart_items_count = get_cart_items_count(request)
    
    return render(request, 'catalog/cart/detail.html', {
        'cart_items': cart_items,
        'cart_total': cart_total,
        'cart_items_count': cart_items_count,
    })

@require_POST
def cart_update(request, product_id):
    quantity = int(request.POST.get('quantity', 1))
    if quantity > 0:
        update_cart_item(request, product_id, quantity)
    else:
        remove_from_cart(request, product_id)
    return redirect('cart_detail')

@require_POST
def cart_clear(request):
    clear_cart(request)
    return redirect('cart_detail')
###

def index(request):
    return render(request, 'catalog/index.html')

class ProductListView(ListView):
    model = Product
    template_name = 'catalog/product_list.html'
    context_object_name = 'products'
    
    def get_queryset(self):
        return Product.objects.filter(is_deleted=False)

class ProductDetailView(DetailView):
    model = Product
    template_name = 'catalog/product_detail.html'
    context_object_name = 'product'
    pk_url_kwarg = 'product_id'

def add_product(request):
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('product_list')
    else:
        form = ProductForm()
    return render(request, 'catalog/add_product.html', {'form': form})

class CategoryListView(ListView):
    model = Category
    template_name = 'catalog/category_list.html'
    context_object_name = 'categories'

def category_products(request, category_id):
    category = get_object_or_404(Category, pk=category_id)
    products = Product.objects.filter(category=category, is_deleted=False)
    return render(request, 'catalog/category_products.html', {'category': category, 'products': products})

def add_category(request):
    if request.method == 'POST':
        form = CategoryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('category_list')
    else:
        form = CategoryForm()
    return render(request, 'catalog/add_category.html', {'form': form})

class TagListView(ListView):
    model = Tag
    template_name = 'catalog/tag_list.html'
    context_object_name = 'tags'

def tag_products(request, tag_id):
    tag = get_object_or_404(Tag, pk=tag_id)
    products = tag.product_set.filter(is_deleted=False)
    return render(request, 'catalog/tag_products.html', {'tag': tag, 'products': products})

from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.contrib import messages

def cart_view(request):
    cart = request.session.get('cart', {})
    products = []
    total_price = 0
    
    for product_id, item in cart.items():
        product = get_object_or_404(Product, pk=product_id)
        quantity = item['quantity']
        products.append({
            'product': product,
            'quantity': quantity,
            'total': product.price * quantity
        })
        total_price += product.price * quantity
    
    return render(request, 'catalog/cart.html', {
        'products': products,
        'total_price': total_price
    })

@require_POST
def add_to_cart(request, product_id):
    cart = request.session.get('cart', {})
    product = get_object_or_404(Product, pk=product_id)
    
    if str(product_id) in cart:
        cart[str(product_id)]['quantity'] += 1
    else:
        cart[str(product_id)] = {
            'quantity': 1,
            'price': str(product.price)
        }
    
    request.session['cart'] = cart
    return JsonResponse({'success': True, 'cart_total': len(cart)})

@require_POST
def remove_from_cart(request, product_id):
    cart = request.session.get('cart', {})
    
    if str(product_id) in cart:
        del cart[str(product_id)]
        request.session['cart'] = cart
    
    return redirect('cart_view')

def create_order(request):
    cart = request.session.get('cart', {})
    
    if not cart:
        messages.error(request, "Ваша корзина пуста")
        return redirect('product_list')
    
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            order = form.save(commit=False)
            order.number = f"ORD-{timezone.now().strftime('%Y%m%d-%H%M%S')}"
            order.save()
            
            for product_id, item in cart.items():
                product = Product.objects.get(pk=product_id)
                OrderItem.objects.create(
                    order=order,
                    product=product,
                    quantity=item['quantity'],
                    discount_per_item=0
                )
            
            del request.session['cart']
            messages.success(request, f"Ваш заказ №{order.number} успешно оформлен!")
            return redirect('order_success', order_id=order.id)
    else:
        form = OrderForm()
    
    return render(request, 'catalog/create_order.html', {
        'form': form,
        'cart': cart
    })

def order_success(request, order_id):
    order = get_object_or_404(Order, pk=order_id)
    return render(request, 'catalog/order_success.html', {'order': order})