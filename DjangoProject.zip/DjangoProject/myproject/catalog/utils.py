from .models import Cart, CartItem, Product

def get_or_create_cart(request):
    if not request.session.session_key:
        request.session.create()
    
    cart, created = Cart.objects.get_or_create(
        session_key=request.session.session_key
    )
    return cart

def get_cart_items(request):
    cart = get_or_create_cart(request)
    return cart.items.all()

def add_to_cart(request, product_id, quantity=1):
    cart = get_or_create_cart(request)
    product = Product.objects.get(id=product_id)
    
    cart_item, created = CartItem.objects.get_or_create(
        cart=cart,
        product=product,
        defaults={'quantity': quantity}
    )
    
    if not created:
        cart_item.quantity += quantity
        cart_item.save()
    
    return cart_item

def remove_from_cart(request, product_id):
    cart = get_or_create_cart(request)
    CartItem.objects.filter(cart=cart, product_id=product_id).delete()

def update_cart_item(request, product_id, quantity):
    cart = get_or_create_cart(request)
    cart_item = CartItem.objects.get(cart=cart, product_id=product_id)
    cart_item.quantity = quantity
    cart_item.save()
    return cart_item

def clear_cart(request):
    cart = get_or_create_cart(request)
    cart.items.all().delete()

def get_cart_total(request):
    cart = get_or_create_cart(request)
    return sum(item.product.price * item.quantity for item in cart.items.all())

def get_cart_items_count(request):
    cart = get_or_create_cart(request)
    return cart.items.count()